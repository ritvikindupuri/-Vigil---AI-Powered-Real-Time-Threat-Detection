import React, { useState, useCallback } from 'react';

interface SettingsModalProps {
    currentThreshold: number;
    currentTriggers: string[];
    onClose: () => void;
    onSave: (settings: { threshold: number, triggers: string[] }) => void;
}

const SettingsModal: React.FC<SettingsModalProps> = ({ currentThreshold, currentTriggers, onClose, onSave }) => {
    const [threshold, setThreshold] = useState(currentThreshold);
    const [triggers, setTriggers] = useState(currentTriggers.join('\n'));

    const handleSave = useCallback(() => {
        const triggerArray = triggers.split('\n').map(t => t.trim()).filter(Boolean);
        onSave({ threshold, triggers: triggerArray });
    }, [threshold, triggers, onSave]);

    return (
        <div 
            className="fixed inset-0 bg-black/60 backdrop-blur-sm flex items-center justify-center z-50 animate-fade-in"
            onClick={onClose}
        >
            <div 
                className="bg-[var(--c-surface)] rounded-xl shadow-2xl w-full max-w-lg max-h-[90vh] flex flex-col m-4"
                onClick={(e) => e.stopPropagation()}
            >
                <div className="flex justify-between items-center p-6 border-b border-[var(--c-border)]">
                    <h2 className="text-xl font-bold text-white">Administrator Controls</h2>
                    <button 
                        onClick={onClose} 
                        className="p-2 rounded-full text-slate-400 hover:text-white hover:bg-[var(--c-surface-light)]"
                    >
                         <svg className="w-6 h-6" fill="none" stroke="currentColor" viewBox="0 0 24 24" xmlns="http://www.w3.org/2000/svg"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M6 18L18 6M6 6l12 12" /></svg>
                    </button>
                </div>
                <div className="p-6 space-y-6 overflow-y-auto">
                    {/* Object Risk Threshold */}
                    <div>
                        <label htmlFor="risk-threshold" className="block text-sm font-medium text-slate-300 mb-2">
                            Object Risk Score Threshold
                        </label>
                        <p className="text-xs text-slate-400 mb-3">
                            Set the sensitivity for high-risk object alerts. A lower value is more sensitive.
                        </p>
                        <div className="flex items-center gap-4">
                            <input
                                id="risk-threshold"
                                type="range"
                                min="40"
                                max="90"
                                value={threshold}
                                onChange={(e) => setThreshold(Number(e.target.value))}
                                className="w-full h-2 bg-[var(--c-border)] rounded-lg appearance-none cursor-pointer accent-[var(--c-accent)]"
                            />
                            <span className="font-bold text-lg text-[var(--c-accent)] w-12 text-center">{threshold}</span>
                        </div>
                    </div>

                    {/* Custom Verbal Triggers */}
                    <div>
                        <label htmlFor="verbal-triggers" className="block text-sm font-medium text-slate-300 mb-2">
                            Custom Verbal Triggers
                        </label>
                        <p className="text-xs text-slate-400 mb-3">
                            Enter words or phrases that should always trigger a verbal alert. Add one per line.
                        </p>
                        <textarea
                            id="verbal-triggers"
                            value={triggers}
                            onChange={(e) => setTriggers(e.target.value)}
                            rows={5}
                            placeholder="e.g., lockdown&#10;code red&#10;bully's nickname"
                            className="w-full bg-[var(--c-bg)] text-slate-200 p-3 rounded-md border border-[var(--c-border)] text-sm focus:ring-2 focus:ring-[var(--c-accent)] focus:border-[var(--c-accent)] transition"
                        />
                    </div>
                </div>
                <div className="flex justify-end items-center p-6 border-t border-[var(--c-border)] bg-[var(--c-surface-light)] rounded-b-xl">
                    <button
                        onClick={onClose}
                        className="text-slate-300 font-semibold py-2 px-4 rounded-lg hover:bg-slate-600/50 transition-colors mr-3"
                    >
                        Cancel
                    </button>
                    <button
                        onClick={handleSave}
                        className="bg-indigo-600 text-white font-bold py-2 px-6 rounded-lg hover:bg-indigo-500 transition-all duration-200 shadow-lg shadow-indigo-500/20"
                    >
                        Save Settings
                    </button>
                </div>
            </div>
        </div>
    );
};

export default SettingsModal;
