
# Vigil 👁️ - AI-Powered Real-Time Threat Detection

<p align="center">
  <strong>Advanced AI surveillance for proactive threat identification. Intelligent monitoring for a safer environment.</strong>
</p>

<p align="center">
  <img src="https://storage.googleapis.com/agentsea-gallery/vigil-demo.gif" alt="Vigil Live Demo" width="90%"/>
</p>

<p align="center">
    <img src="https://img.shields.io/badge/React-19-blue?logo=react&logoColor=white" alt="React 19">
    <img src="https://img.shields.io/badge/TypeScript-5.x-blue?logo=typescript&logoColor=white" alt="TypeScript">
    <img src="https://img.shields.io/badge/AI-Google%20Gemini-purple?logo=google&logoColor=white" alt="Google Gemini">
    <img src="https://img.shields.io/badge/License-MIT-green" alt="License: MIT">
</p>

---

**Vigil** transforms any webcam into an AI-powered security system. Running entirely in your browser, it uses Google Gemini to analyze live video and audio for threats like physical aggression, risky objects, and verbal bullying. Vigil provides real-time alerts and on-screen annotations to help create safer environments.

## ✨ Key Features

Vigil is more than just a camera feed; it's a proactive safety solution.

| Feature | Description |
| :--- | :--- |
| 🧠 **Real-Time Multi-Threat Analysis** | Simultaneously analyzes the feed for multiple threats: **physical aggression** (punching, hostile stances), **high-risk objects** (with risk scoring and justification), and **verbal threats** (bullying, harassment). |
| 🎯 **Dynamic On-Screen Annotations** | Overlays the live feed with color-coded bounding boxes and labels, providing instant visual context for each tracked person and detected threat. Red for aggression, yellow for risky objects, and blue for tracking. |
| 🔔 **Instant Event Logging** | Every detected incident is immediately logged with a timestamp, type, title, and detailed AI-generated explanation. This creates an immutable record of events as they happen. |
| 📇 **Professional Session Management** | Includes a full workflow for security professionals: archive incidents into timestamped sessions, review them in a detailed history log, and generate formal, copy-paste-ready reports for documentation or escalation. |
| 🔒 **Privacy-First Architecture** | **Your privacy is paramount.** All processing is done client-side. Raw video and audio streams **never leave your browser**. Only individual image frames and text snippets are sent to the AI for analysis. |

## 🚀 Technology Stack

Vigil is built with a modern, performant, and reliable tech stack, running entirely in the browser with no server-side installation required.

| Category      | Technology                                                                                                    |
| :------------ | :------------------------------------------------------------------------------------------------------------ |
| **Frontend**  | `React 19`, `TypeScript`, `TailwindCSS`                                                                       |
| **AI Model**  | `Google Gemini API (@google/genai)` for image and language understanding.                                    |
| **Browser APIs** | `WebRTC (getUserMedia)` for secure camera/mic access, `Web Speech API` for speech-to-text.                    |
| **Deployment**| Serveless, via ESM modules (`esm.sh`) for dependency management without a build step.                              |

## 🛠️ How It Works

Vigil's intelligence is built on an efficient, client-side data flow that prioritizes both speed and privacy.

1.  **Activation:** The user clicks "Start Monitoring."
2.  **Capture:** The browser securely accesses the camera and microphone streams using standard, permission-based Web APIs.
3.  **Analysis Loops:** Two asynchronous loops run in parallel:
    *   📸 **Image Analysis (`~1.5s interval`):** A frame is captured from the video, converted to Base64, and sent to the Gemini API with a highly specific prompt to identify people, aggression, and held objects. The model returns structured JSON.
    *   🗣️ **Verbal Analysis (`~5s interval`):** The Web Speech API captures and transcribes audio. The resulting text is sent to the Gemini API to analyze for sentiment and bullying, returning structured JSON.
4.  **Feedback & Logging:** The structured JSON responses from the AI are used to instantly update the UI with on-screen bounding boxes and add detailed alerts to the Event Log.

```mermaid
graph TD
    A[User Clicks Start] --> B{Activate Camera & Mic};
    B --> C{Image Analysis Loop};
    B --> D{Verbal Analysis Loop};

    subgraph "Client-Side (Browser)"
        C -- Frame (JPEG) --> E[Google Gemini API];
        D -- Text Snippet --> E;
    end

    subgraph "Google Cloud"
        E -- Structured JSON --> F{Update UI};
    end
    
    F --> G[Display Annotations on Video];
    F --> H[Add Alert to Event Log];
```

## ⚙️ Getting Started (Local Development)

To run Vigil on your local machine, follow these steps.

### Prerequisites
- A modern web browser (Chrome, Firefox, Edge).
- A valid **Google Gemini API Key**. You can obtain one from [Google AI Studio](https://aistudio.google.com/app/apikey).
- [Node.js](https://nodejs.org/) and `npm` for running a simple local server.

### Installation & Setup

1.  **Clone the repository:**
    ```bash
    git clone https://github.com/your-username/vigil.git
    cd vigil
    ```

2.  **Set up your API Key:**
    The application is designed to load the API key from environment variables. For local development, you can simulate this by manually editing the code where `process.env.API_KEY` is used, but for a production-like setup, a local dev server that can handle environment variables is recommended.
    
    *Create a file named `.env` in the root of the project and add your key:*
    ```
    API_KEY=YOUR_GEMINI_API_KEY_HERE
    ```
    *Note: You will need a local dev server capable of injecting environment variables, like Vite or `dotenv` with a custom server script.*

3.  **Run with a simple static server:**
    For a quick start without environment variable injection (manual code edit required), you can use a simple server.
    ```bash
    # Install 'serve' globally
    npm install -g serve

    # Run the server from the project root
    serve
    ```

4.  **Open the application:**
    Navigate to the local URL provided by the server (e.g., `http://localhost:3000`) in your browser.

## 📄 License

This project is licensed under the MIT License. See the [LICENSE](LICENSE.md) file for details.
