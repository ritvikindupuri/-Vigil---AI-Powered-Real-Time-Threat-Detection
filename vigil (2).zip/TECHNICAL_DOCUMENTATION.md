# Vigil - Technical Documentation

**Version:** 1.0.0
**Date:** [Current Date]

---

## 1. Project Overview

**Vigil** is a state-of-the-art, browser-based security surveillance application designed for real-time threat detection in environments like schools, public spaces, and workplaces. Leveraging the power of the Google Gemini AI model, Vigil analyzes live video and audio streams to proactively identify and log potential dangers, including physical aggression, high-risk objects, and verbal bullying.

The system is engineered to provide immediate, actionable intelligence to security personnel, administrators, and staff, enabling faster responses to incidents and creating a safer environment. Its intuitive dashboard, real-time alerts, and comprehensive session reporting make it a powerful tool for modern security needs.

---

## 2. Key Features

### 2.1. Real-Time Multi-Person Threat Analysis
Vigil's core capability is its real-time analysis of the video feed, which can distinguish and track multiple individuals simultaneously. For each person detected, the system performs an independent analysis for:
- **Physical Aggression:** Identifies actions like punching, fighting, aggressive stances, and other physically hostile behaviors.
- **Object Detection & Risk Assessment:** Detects objects held by individuals, assesses their inherent risk (0-100 score), and identifies when a safe object is being used in a threatening manner.
- **Verbal Threat Detection:** Analyzes ambient audio captured by the microphone to identify signs of bullying, harassment, and negative sentiment.

### 2.2. Administrator Control Panel
This advanced feature empowers administrators with real-time control over the AI's sensitivity, making the system adaptable to specific environments and situations.
- **Adjustable Risk Threshold:** A slider allows administrators to set the risk score (40-90) at which an object should trigger an alert. **This setting does not change the AI's score; it defines the *minimum score required* to generate an alert.** This separation of duties allows administrators to decrease sensitivity during normal activities (e.g., an art class with scissors by setting the threshold to 80) or increase it during high-alert situations (by lowering it to 50).
- **Custom Verbal Triggers:** A dedicated input for adding school-specific slang, code words, or names. Any phrase on this list will immediately trigger a high-priority verbal alert, "teaching" the AI about local context it wouldn't otherwise know.

### 2.3. AI-Powered Daily Executive Summary
From the Session History modal, administrators can use a one-click button to generate an AI-written executive summary of the day's events. The AI analyzes all archived session data to identify trends, peak activity times, and the most common threat types, providing a high-level, actionable brief perfect for management review.

### 2.4. Live Video Feed with Dynamic Annotations
The central UI component is the live video feed, which is overlaid with dynamic, color-coded bounding boxes and labels. These annotations provide instant visual context, highlighting:
- The individuals being tracked.
- The specific threats associated with each person (e.g., "AGGRESSION DETECTED", "RISK: Knife (95)").
- The status of the AI processing loops.

### 2.5. Dynamic Event Log & Professional Incident Reporting
- **Event Log:** All detected threats are immediately logged as discrete alerts in a real-time panel.
- **Professional Reports:** A formal, cleanly formatted text-based incident report can be generated and copied to the clipboard for any session (live or archived). The professional layout is optimized for record-keeping, emailing, or police reports.
- **Session Management:** Administrators can "Reset Session" to close out an active monitoring period. This action archives all current alerts as a single, timestamped session in the History Modal for later review.

---

## 3. System Architecture

Vigil is a single-page application (SPA) built entirely with modern web technologies. It runs completely in the user's browser, making it highly accessible and easy to deploy without server-side installation.

- **Frontend Framework:** **React 19** with TypeScript for robust, type-safe component development.
- **Core Technologies:**
    - **TypeScript:** Ensures code quality and maintainability.
    - **TailwindCSS:** For rapid, utility-first styling.
    - **WebRTC (`getUserMedia`):** To access the camera and microphone feeds securely.
    - **Web Speech API:** For capturing audio and converting it to text for analysis.
- **AI Integration:** **Google Gemini API** (`@google/genai`) is used for all intelligent analysis.
- **Structure:** The application follows a modular, component-based architecture. State management is handled within the main `App.tsx` component using React Hooks (`useState`, `useCallback`, `useRef`, `useEffect`).

### Component Breakdown

- **`App.tsx`**: The root component. It orchestrates the entire application, manages global state (monitoring status, alerts, history, admin settings), and contains the core logic for the analysis loops.
- **`Header.tsx`**: The global navigation bar. It displays branding, key threat metrics, and provides primary controls for starting/stopping monitoring, resetting sessions, and opening the history and settings modals.
- **`LiveMonitoringView.tsx`**: Manages the video element, camera access, frame capture, and rendering of all visual annotations over the live feed.
- **`EventLog.tsx`**: Displays the real-time list of alerts and contains the "Generate Report" functionality for the current session.
- **`HistoryModal.tsx`**: A modal component that displays a list of archived sessions and includes the button to trigger the AI Daily Executive Summary generation.
- **`SettingsModal.tsx`**: A modal component providing the UI for the Administrator Control Panel, allowing for real-time adjustment of AI parameters.
- **`services/geminiService.ts`**: A dedicated service module that encapsulates all communication with the Google Gemini API. It handles the formatting of requests, defining response schemas, and parsing the AI's JSON output.

---

## 4. AI Integration & Data Flow

Vigil's intelligence is powered by three main functions in `geminiService.ts`.

### 4.1. Image Analysis (`analyzeImageContent`)
- **Trigger:** A frame is captured from the `<video>` element as a Base64-encoded JPEG every ~1.5 seconds.
- **Prompt Engineering:** A highly directive prompt instructs the Gemini model to act as a security system, focusing on human actions and held objects while ignoring static background items.
- **AI Risk Scoring:** The Gemini model analyzes any held object and returns its own objective `riskScore` (0-100) based on its training data.
- **Administrator-Controlled Alerting:** The application logic then compares the AI's returned `riskScore` against the administrator-defined `objectRiskThreshold`. **An alert is only generated if `riskScore > objectRiskThreshold`.** This is how the system achieves adjustable sensitivity without altering the AI's core analysis.
- **JSON Schema:** A strict `responseSchema` is enforced, requiring the model to provide structured, reliable data for each person detected.
- **Low Latency:** The API call is configured with `thinkingConfig: { thinkingBudget: 0 }` to ensure the fastest possible response time.

### 4.2. Verbal Analysis (`analyzeVerbalContent`)
- **Trigger:** The Web Speech API continuously buffers finalized speech transcripts. This buffer is sent for analysis periodically (every ~5 seconds).
- **Custom Triggers:** The function accepts an array of `customVerbalTriggers` from the Administrator Control Panel. These words are injected directly into the system instruction, forcing the AI to flag any text containing them as a high-priority threat, regardless of its own sentiment analysis.
- **JSON Schema:** The model returns a structured JSON object with `sentiment`, `isBullying`, and an `explanation`.

### 4.3. Daily Summary Generation (`generateDailySummary`)
- **Trigger:** An administrator clicks the "Generate Daily Executive Summary" button in the History Modal.
- **Data Aggregation:** The function compiles a simplified list of all archived session summaries (e.g., "Session from 10:30 AM: 3 aggression, 1 verbal, 0 objects.").
- **Prompting:** This aggregated data is sent to the Gemini API with a system instruction for it to act as a senior security analyst. The prompt asks for a concise executive brief, including total incident counts, peak times, and an overall assessment.

### Data Flow Overview
Administrative settings (risk thresholds, custom triggers) are saved in the main `App.tsx` state. These settings are then passed into the core analysis loops, directly influencing the logic within `geminiService.ts` on each call. This ensures that every AI analysis uses the most current, administrator-defined parameters.

---

## 5. Security, Privacy, and Performance

### 5.1. Data Privacy (Client-Side Processing)
This is a cornerstone of Vigil's design. **All processing is performed locally on the client's machine.**
- **No Video/Audio Upload:** The raw video and audio streams are **never** sent to any server. They remain within the user's browser.
- **Data Sent to AI:** The only data sent to the Google Gemini API are individual, compressed image frames (as Base64 strings) and snippets of transcribed text. No continuous video or audio is ever streamed externally.
- **No Data Storage:** Vigil does not store any video or audio data. The Event Log and Session History are stored in the browser's memory and are cleared when the page is closed, unless a report is manually generated and saved by the user.

### 5.2. Security
- **Secure Camera Access:** The application uses the standard, secure WebRTC API (`getUserMedia`) to request camera and microphone access, which requires explicit user permission.
- **API Key Management:** The Google Gemini API key is managed as an environment variable and is not exposed in the client-side code, preventing unauthorized use.

### 5.3. Performance
- **Client-Side Load:** Since all processing is local, the application's performance depends on the client machine's CPU/GPU capabilities.
- **Optimized Analysis Loop:** The analysis interval is set to ~1.5 seconds as a balance between real-time responsiveness and manageable API usage. A dynamic backoff mechanism is in place to automatically slow down requests if API rate limits are hit, preventing errors.
- **Graceful Error Handling:** The UI includes visible error banners to inform the user of critical issues, such as camera permission denial or Gemini API failures, ensuring the user is always aware of the system's operational status.


---

## 7. Future Enhancements

Vigil is built on a scalable architecture. Future development could include:

-   **Backend & Database:** A dedicated backend service (e.g., Node.js, Python) with a database (e.g., PostgreSQL) to store user accounts, persistent session history, and manage API keys securely.
-   **Speaker Diarization:** Implementing more advanced audio processing to distinguish *who* is speaking in a multi-person environment.
-   **Cross-Frame Object Tracking:** Enhancing the AI to track a single person or object consistently across multiple frames, even with temporary obstructions.
-   **Mobile Notifications:** Integrating push notification services to alert administrators of high-priority threats even when they are not actively viewing the dashboard.