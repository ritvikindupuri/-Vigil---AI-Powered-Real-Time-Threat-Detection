
# Vigil - Official Demonstration Script

**Objective:** To provide a comprehensive, step-by-step demonstration of Vigil's core features, showcasing its real-time AI analysis, multi-person tracking, and professional session management capabilities.

**Audience:** Investors, School Administrators, Security Personnel, Potential Employers.

---

### **Preparation**

1.  **Actors & Props:**
    *   It is highly recommended to have **one colleague** to assist with the multi-person scenario.
    *   **Props:**
        *   A **safe object** (e.g., a coffee mug, a smartphone).
        *   A **"risky" object** (e.g., a pair of scissors, a large screwdriver, or simply making a very tight fist to simulate holding a weapon).

2.  **Initial State:**
    *   Open the Vigil application in your browser.
    *   Ensure the application is in its default state: the "Start" button is visible, the status is "OFFLINE," and the Event Log is empty.

---

### **Part 1: System Activation & Core Monitoring**

**Goal:** Demonstrate the system's startup and baseline monitoring state.

| Step | Action | Narration / Key Points to Mention |
| :--- | :--- | :--- |
| 1.1 | Click the **"Start"** button. | "We begin by activating Vigil's monitoring system. With a single click, the application securely accesses the camera feed and initiates its AI analysis loops." |
| 1.2 | Point to the UI changes. | "Notice three immediate changes: <br>1. The header status is now **'ACTIVE'** with a green, pulsing light, indicating the system is live. <br>2. The video feed is active. <br>3. The status bar at the bottom of the video confirms that both **Image** and **Verbal** analysis are running." |

---

### **Part 2: Single-Person Threat Detection Scenarios**

**Goal:** Showcase the AI's ability to identify and differentiate between various types of threats from a single individual.

| Step | Action | Narration / Key Points to Mention |
| :--- | :--- | :--- |
| 2.1 | **Verbal Threat:** Speak clearly into the microphone: **"You're useless, I'm going to get you."** | "Vigil's verbal analysis is constantly listening for signs of bullying or harassment. As you can see, a **'Verbal Warning'** alert instantly appeared in the Event Log, capturing the sentiment and the exact phrase." |
| 2.2 | **Safe Object:** Hold up the **safe object** (phone/mug) in a normal, non-threatening way. | "The AI is constantly analyzing objects. It correctly identifies the phone, but as you can see, no alert is generated. Its risk score is low, and the system intelligently ignores non-threats to prevent false alarms." |
| 2.3 | **High-Risk Object:** Hold up the **"risky" object** (scissors/fist). | "Now, when a potentially high-risk object is introduced, the system immediately flags it. A **yellow warning box** appears on-screen, and a **'Risky Object'** alert is logged with the AI's calculated risk score and justification." |
| 2.4 | **Contextual Threat:** Take the **safe object** (phone) and make an aggressive swinging motion towards the camera. | "This demonstrates the AI's understanding of **context**. The phone itself isn't a threat, but the way it's being used is. The system generates a **'Contextual Threat'** alert, warning that a safe object is being used harmfully." |
| 2.5 | **Physical Aggression:** Make a fist and punch the air, or take an aggressive stance. | "Finally, the system analyzes body language for physical threats. It has identified aggressive indicators, creating a **red, high-priority alert** and drawing a corresponding box on screen. The system doesn't just see objects; it understands actions." |

---

### **Part 3: Advanced Multi-Person Scenario**

**Goal:** The key differentiator. Demonstrate Vigil's ability to track and analyze multiple individuals and their independent actions simultaneously.

| Step | Action | Narration / Key Points to Mention |
| :--- | :--- | :--- |
| 3.1 | Have your colleague enter the camera frame alongside you. | "Real-world situations are rarely simple. Here is where Vigil truly excels. We now have two individuals in the frame." |
| 3.2 | **You (Person A):** Perform an aggressive action (e.g., a pushing motion towards your colleague). <br><br> **Colleague (Person B):** Hold up the **"risky" object**. | "Now, we have a complex scenario with multiple simultaneous threats. Person A is showing aggression, while Person B is holding a high-risk object." |
| 3.3 | Point to the screen and the Event Log. | "This is the critical part. Vigil is not confused. It is tracking each person **independently**. <br>1. It has drawn a **red box around Person A** for aggression. <br>2. It has drawn a **yellow box around Person B** for the object. <br>3. Most importantly, in the Event Log, it has created **two separate, distinct alerts**, correctly attributing each action to the right person. This level of detail is crucial for accurate incident reporting." |

---

### **Part 4: Session Management & Reporting Workflow**

**Goal:** Showcase the professional administrative tools for managing and documenting incidents.

| Step | Action | Narration / Key Points to Mention |
| :--- | :--- | :--- |
| 4.1 | Point to the Event Log. Click the **"Generate Report"** button. | "Once an incident has occurred, documentation is key. With one click, Vigil compiles a complete incident report for the current session." |
| 4.2 | Open a text editor (Notepad, etc.) and paste (Ctrl+V). | "The report is copied directly to the clipboard. As you can see when I paste it here, it's a clean, timestamped document with a summary and a detailed log of every event, ready to be saved or emailed." |
| 4.3 | Click the **"Reset Session"** button in the header. | "At the end of an incident or a shift, an administrator can reset the session. This archives the previous events and clears the dashboard, preparing the system for a fresh start." |
| 4.4 | Point to the cleared Event Log and the metrics in the header, now at zero. | "The live dashboard is now clean, but no data has been lost." |
| 4.5 | Click the **"History"** button in the header. | "All previous sessions are securely archived in the Session History." |
| 4.6 | In the modal, point to the top entry (the session you just archived). Click to expand it. | "Here is the session we just archived, with a clear summary of all threats. We can review every alert in detail." |
| 4.7 | Click the **"Generate Report"** button within that archived session. Paste into the text editor. | "Crucially, a formal report can be generated for any past incident at any time, ensuring a complete and auditable history is always available." |
| 4.8 | Close the History modal. | |

---

### **Part 5: System Deactivation & Conclusion**

| Step | Action | Narration / Key Points to Mention |
| :--- | :--- | :--- |
| 5.1 | Click the **"Stop"** button. | "And finally, we can deactivate the system. The camera feed stops, and all monitoring ceases." |
| 5.2 | **Summary:** | "In this brief demonstration, we've shown how Vigil provides **end-to-end security management**. It moves beyond simple detection to offer **multi-person analysis**, understands the **context** of threats, and provides the **professional reporting tools** needed for effective incident response. It is a proactive, intelligent, and indispensable tool for creating a safer environment." |
